//! 悬浮字幕窗挂载点（subtitle.html 入口；与主应用共享 React 依赖）。

import { createRoot } from 'react-dom/client';
import OverlayApp from './OverlayApp';
import './overlay.css';

const el = document.getElementById('root');
if (el) {
  createRoot(el).render(<OverlayApp />);
}
