//! 小窗面板挂载点（panel.html 入口）。

import { createRoot } from 'react-dom/client';
import PanelApp from './PanelApp';
import '../../../styles/_tokens/variables.css';
// 小窗会渲染 AI 回复（MemoMarkdown 输出 .md 结构），必须带上阅读样式，
// 否则标题/列表/代码块全按浏览器默认样式显示。
import '../../../styles/_tokens/markdown.css';
import './panel.css';
import { loadUiScale } from '../../../lib/uiScale';

// 小窗是独立文档，主窗设置的全局字号不会自动继承；同源 localStorage 里读一次即可。
document.documentElement.style.setProperty('--ui-scale', String(loadUiScale()));

const el = document.getElementById('root');
if (el) {
  createRoot(el).render(<PanelApp />);
}
