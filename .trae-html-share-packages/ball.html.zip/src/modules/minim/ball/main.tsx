//! 悬浮球挂载点（ball.html 入口）。

import { createRoot } from 'react-dom/client';
import BallApp from './BallApp';
import '../../../styles/_tokens/variables.css';
import './ball.css';

const el = document.getElementById('root');
if (el) {
  createRoot(el).render(<BallApp />);
}
